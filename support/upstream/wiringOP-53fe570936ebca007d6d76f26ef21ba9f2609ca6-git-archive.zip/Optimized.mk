# Default release optimization policy for the StableKite integration branch.
#
# Keep the generic build portable: use maximum release optimization and LTO on
# every host, but only enable CPU-specific tuning for a native Orange Pi 5
# AArch64 build. All variables remain overridable from the make command line.

WIRINGOP_OPT_FLAGS ?= -O3
WIRINGOP_RELEASE_DEFS ?= -DNDEBUG
WIRINGOP_LTO_FLAGS ?= -flto=auto

WIRINGOP_UNAME_S := $(shell uname -s 2>/dev/null)
WIRINGOP_UNAME_M := $(shell uname -m 2>/dev/null)
WIRINGOP_BOARD_MODEL := $(shell if [ -r /proc/device-tree/model ]; then tr -d '\000' < /proc/device-tree/model 2>/dev/null; fi)

WIRINGOP_CPU_FLAGS ?=
ifeq ($(WIRINGOP_UNAME_S),Linux)
ifneq ($(filter aarch64 arm64,$(WIRINGOP_UNAME_M)),)
ifneq ($(findstring Orange Pi 5,$(WIRINGOP_BOARD_MODEL)),)
WIRINGOP_CPU_FLAGS := -mcpu=native
endif
endif
endif

WIRINGOP_RELEASE_FLAGS = $(WIRINGOP_OPT_FLAGS) $(WIRINGOP_RELEASE_DEFS) $(WIRINGOP_LTO_FLAGS) $(WIRINGOP_CPU_FLAGS)
WIRINGOP_LINK_FLAGS = $(WIRINGOP_OPT_FLAGS) $(WIRINGOP_LTO_FLAGS) $(WIRINGOP_CPU_FLAGS)
